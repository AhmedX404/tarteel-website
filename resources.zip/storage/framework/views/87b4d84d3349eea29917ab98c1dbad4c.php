<?php $__env->startSection('content'); ?>
    <style>
        body{
            overflow: hidden;
        }
    </style>
    <div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
        <div class="container">
           <?php if(session()->has('user_name')): ?>
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="text-center"> <?php echo e(session()->get('user_name')); ?>  مرحبا بك</h4>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <a draggable="false" class="btn btn-secondary btn-lg" style="width: 60%" href="<?php echo e(route('courses')); ?>">دوراتي </a>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <a class="btn btn-secondary btn-lg" style="width: 60%" href="<?php echo e(route('logout')); ?>">تسجيل الخروج </a>
                    </div>
                </div>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="text-center">مرحبا بك</h4>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <a class="btn btn-secondary btn-lg" href="<?php echo e(route('login.page')); ?>">تسجيل الدخول</a>
                    </div>
                </div>
           <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AhmedOmar\Desktop\Almaher\AlMaher-Laravel\Al-Maher\resources\views/pages/app.blade.php ENDPATH**/ ?>