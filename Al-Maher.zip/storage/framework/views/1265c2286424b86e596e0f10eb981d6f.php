<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-center" >
        <div class="row justify-content-center" >
            <div class="col-md-12" >
                <div class="container">
                    <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card m-3 border-0" style="width: 24rem">
                            <a href="<?php echo e(route('lesson.data',$lesson->id)); ?>">
                                <img class="card-img-top"  src="<?php echo e(asset('class_select.jpg')); ?>" alt="Course image">
                                <div class="card-body">
                                    <div class="col-12 col-md-12 col-lg-12 mx-auto">
                                        <a href="<?php echo e(route('lesson.data',$lesson->id)); ?>" style="text-decoration: none;">
                                            <h5 class="card-title text-center text-black"><?php echo e($lesson->name); ?></h5><br>
                                        </a>
                                        <a href="<?php echo e(route('lesson.data',$lesson->id)); ?>" class="btn btn-primary" style="width: 100%">أختر</a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AhmedOmar\Desktop\Almaher\AlMaher-Laravel\Al-Maher\resources\views/pages/courses/course-data.blade.php ENDPATH**/ ?>